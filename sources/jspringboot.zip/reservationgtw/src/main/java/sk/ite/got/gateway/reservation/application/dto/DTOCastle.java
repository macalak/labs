package sk.ite.got.gateway.reservation.application.dto;


public class DTOCastle {
	public Long id;
	public String name;
}
