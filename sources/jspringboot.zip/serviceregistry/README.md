# serviceregistry
Services registration server based on Netflix Eureka. Services requires Netflix Eureka client.

* Supports HA Service registry setup
* Spring also supports HashiCorp Consul registry implementation.

# Try it
* The Eureka Web GUI http://localhost:8761/
 
 
