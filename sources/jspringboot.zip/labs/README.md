# Microservices course labs

1. [Architecture](architecture.md)
2. [DDD](ddd.md)
3. [Config server](configserver.md)
4. [Service registry](registry.md)
5. [API Gateway](gateway.md)
6. [Deployment](deployment.md)
6. [DevOps](devops.md)
4. [Development process](dev_proccess.md)

## References
* https://start.spring.io/
