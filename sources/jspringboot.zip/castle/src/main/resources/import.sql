insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values (1,'Harrenhal','House Baelish','The Riverlands',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values (2,'Dragonstone','House Baratheon of Dragonstone','Dragonstone',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values (3,'Casterly Rock','House Lannister','The Westerlands',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values (4,'Winterfell','House Bolton','The North',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values (5,'Riverrun','House Tully','The Westeros',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values (6,'The Eyrie','House Arryn','The Westeros',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values (7,'Castle Black','The Nights Watch','The Westeros',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values (8,'Moat Cailin','House Bolton','The Westeros',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values (9,'The Dreadfort','House Bolton','The Westeros',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values (10,'Red Keep','The King of the Andals and the First Men','Kings Landing',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values (11,'Storm''s End','House Bolton','The Westeros',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values (12,'Highgarden','House Tyrell','The Westeros',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values (14,'The Twins','House Frey','The Westeros',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values (15,'Last Hearth','House Umber','The Westeros',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values (16,'The Citadel','The Conclave, Order of Maesters','The Reach',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values (17,'The Nightfort','The Westeros','The Night''s Watch',1);
alter sequence HIBERNATE_SEQUENCE restart with 18
