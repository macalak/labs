Use this directory as Vgrant working directory, after you imported microservices.box.
Just run `vagrant up`.