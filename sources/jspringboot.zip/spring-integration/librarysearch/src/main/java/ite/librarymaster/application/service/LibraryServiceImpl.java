package ite.librarymaster.application.service;

import ite.librarymaster.application.dto.BookDTO;
import ite.librarymaster.application.exception.ItemNotFoundException;
import ite.librarymaster.domain.model.Book;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;


import ite.librarymaster.domain.model.BookRepository;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.constraints.NotNull;

@Service
public class LibraryServiceImpl implements LibraryService{
    final private static Logger LOG = LoggerFactory.getLogger(LibraryServiceImpl.class);

	@Autowired
	private BookRepository bookRepository;
    @Autowired
    private ModelMapper modelMapepr;


    @Override
    public List<BookDTO> getBooks(@NotNull  Map<String, String> filter) {
        if(filter.isEmpty()){
            LOG.info("Filter is empty. Retrieving all books.");
            return bookRepository.findAll().stream()
                    .map(book -> modelMapepr.map(book, BookDTO.class))
                    .collect(Collectors.toList());

        }else if(filter.containsKey("ISBN")){
            LOG.info("Filter contains ISBN. Retrieving all Book instances with ISBN:{}.",filter.get("ISBN"));
            return bookRepository.findByIsbn(filter.get("ISBN")).stream()
                    .map(book -> modelMapepr.map(book, BookDTO.class))
                    .collect(Collectors.toList());

        } else if(filter.containsKey("AUTHOR") && filter.containsKey("TITLE")){
            LOG.info("Filter contains AUTHOR and TITLE. Retrieving all Book instances with AUTHOR:{} AND TITLE:{}.",
                    filter.get("AUTHOR"),
                    filter.get("TITLE"));
            return bookRepository.findByAuthorAndTitle(filter.get("AUTHOR"), filter.get("TITLE")).stream()
                    .map(book -> modelMapepr.map(book, BookDTO.class))
                    .collect(Collectors.toList());

        } else if(filter.containsKey("AUTHOR")){
            LOG.info("Filter contains AUTHOR. Retrieving all Book instances with AUTHOR:{}.",
                    filter.get("AUTHOR"));
            return bookRepository.findByAuthor(filter.get("AUTHOR")).stream()
                    .map(book -> modelMapepr.map(book, BookDTO.class))
                    .collect(Collectors.toList());

        } else if(filter.containsKey("TITLE")){
            LOG.info("Filter contains TITLE. Retrieving all Book instances with TITLE:{}.",
                    filter.get("TITLE"));
            return bookRepository.findByTitle(filter.get("TITLE")).stream()
                    .map(book -> modelMapepr.map(book, BookDTO.class))
                    .collect(Collectors.toList());
        } else {
            return bookRepository.findAll().stream()
                    .map(book -> modelMapepr.map(book, BookDTO.class))
                    .collect(Collectors.toList());

        }
    }

    @Override
    public Long createBook(BookDTO bookDTO) {
        LOG.info("Creating book with details:{} ...", bookDTO);
        Book createdBook=bookRepository.save(modelMapepr.map(bookDTO, Book.class));
        return createdBook.getId();
    }

    @Override
    public void deleteBook(Long id) throws ItemNotFoundException {
        LOG.info("Deleting book with id{}", id);
        Optional<Book> book = bookRepository.findById(id);
        if(book.isPresent()){
            bookRepository.delete(book.get());
            LOG.info("Book deleted.");
        }else {
            throw new ItemNotFoundException("Book to delete with id=" + id + " not found.");
        }
    }

}
