package ite.librarymaster.infrastructure.messaging;

import ite.librarymaster.application.dto.BookDTO;
import ite.librarymaster.application.event.BookCreatedEvent;
import ite.librarymaster.application.event.BookDeletedEvent;
import ite.librarymaster.application.event.NotificationEvent;
import ite.librarymaster.application.exception.ItemNotFoundException;
import ite.librarymaster.application.service.LibraryService;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.stereotype.Component;

@Component
public class LibraryMessageReceiver {
    final private static Logger LOG = LoggerFactory.getLogger(LibraryMessageReceiver.class);

    @Autowired
    private LibraryService libraryService;
    @Autowired
    private ModelMapper modelMapepr;

    @ServiceActivator(inputChannel = "libraryIntChannel")
    public void receiveMessage(NotificationEvent notificationEvent) {
        LOG.info("Message received {}", notificationEvent);
        if(notificationEvent instanceof BookCreatedEvent) {
            libraryService.createBook(modelMapepr.map(notificationEvent, BookDTO.class));
        } else if(notificationEvent instanceof BookDeletedEvent) {
            try {
                libraryService.deleteBook(((BookDeletedEvent) notificationEvent).id);
            } catch (ItemNotFoundException e) {
                LOG.error("No book with id:{}",((BookDeletedEvent) notificationEvent).id);
            }
        }
    }
}
