package ite.librarymaster.infrastructure.messaging;

import ite.librarymaster.application.event.NotificationEvent;
import org.springframework.integration.annotation.Gateway;
import org.springframework.integration.annotation.MessagingGateway;

@MessagingGateway
public interface LibraryEventPublisher {
    @Gateway(requestChannel = "libraryIntChannel")
    void send(NotificationEvent event );
}
