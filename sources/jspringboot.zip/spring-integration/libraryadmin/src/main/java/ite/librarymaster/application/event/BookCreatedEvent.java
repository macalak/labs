package ite.librarymaster.application.event;

public class BookCreatedEvent extends NotificationEvent{
    public Long id;
    public String isbn;
    public String author;
    public String title;
    public String publisher;
    public String cid;
    public BookGenre genre;
    public MediumAvailability availability;

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("BookCreatedEvent{");
        sb.append("id=").append(id);
        sb.append(", isbn='").append(isbn).append('\'');
        sb.append(", author='").append(author).append('\'');
        sb.append(", title='").append(title).append('\'');
        sb.append(", publisher='").append(publisher).append('\'');
        sb.append(", cid='").append(cid).append('\'');
        sb.append(", genre=").append(genre);
        sb.append(", availability=").append(availability);
        sb.append(super.toString());
        sb.append('}');
        return sb.toString();
    }
}
