package ite.librarymaster.application.event;

public class BookDeletedEvent extends NotificationEvent {
    public Long id;

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("BookDeletedEvent{");
        sb.append("id=").append(id);
        sb.append(", eventId='").append(eventId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
