package ite.librarymaster.application.event;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

import javax.validation.constraints.NotNull;
import java.time.Instant;
import java.util.UUID;

@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "type")
@JsonSubTypes({
        @JsonSubTypes.Type(value = BookCreatedEvent.class, name = "BookCreatedEvent"),
        @JsonSubTypes.Type(value = BookDeletedEvent.class, name = "BookDeletedEvent"),
})
public class NotificationEvent {
    @NotNull
    public String eventId = UUID.randomUUID().toString();

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("DTONotificationEvent{");
        sb.append("id='").append(eventId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
