package ite.librarymaster.application.dto;

public enum BookGenre {
	
	Fiction,
	Fantasy,
	Scifi,
	Crime,
	History,
	Biography,
	Children,
	Military,
	Horor,
	Romance,
	Computing

}
