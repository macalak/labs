package ite.librarymaster.application.service;

import ite.librarymaster.application.dto.BookDTO;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriBuilder;
import org.springframework.web.util.UriBuilderFactory;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class LibrarySearchServiceProxyImpl implements LibrarySearchServiceProxy {
    final private static Logger LOG = LoggerFactory.getLogger(LibrarySearchServiceProxyImpl.class);

    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private ModelMapper modelMapepr;

    @Value("${library.gtw.search.uri}")
    private String searchApiUri;

    @Override
    public List<BookDTO> getBooks(Map<String, String> filter) {
        LOG.info("Retrieving books using Search API ...");
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        // Uncomment to pass JWT token
        // headers.add("Authorization","Bearer "+activeSession.getApiAccessToken());
        HttpEntity httpRequest = new HttpEntity(headers);
        UriComponentsBuilder query = UriComponentsBuilder.newInstance()
                .uri(URI.create(searchApiUri))
                .path("/library/books");
        UriComponents uriComponents = query.build();
        if(filter.get("ISBN")!=null && !filter.get("ISBN").isEmpty()) {
            query.query("isbn={ISBN}");
        }
        if(filter.get("AUTHOR")!=null && !filter.get("AUTHOR").isEmpty()) {
            query.query("author={AUTHOR}");
        }
        if(filter.get("TITLE")!=null && !filter.get("TITLE").isEmpty()) {
            query.query("title={TITLE}");
        }
        uriComponents=query.buildAndExpand(filter);
        ResponseEntity<List<BookDTO>> response = restTemplate.exchange(uriComponents.toUri(),
                HttpMethod.GET, httpRequest, new ParameterizedTypeReference<List<BookDTO>>() {});

        return response.getBody();
    }


}
