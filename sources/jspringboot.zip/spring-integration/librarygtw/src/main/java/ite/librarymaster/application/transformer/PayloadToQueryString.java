package ite.librarymaster.application.transformer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.integration.transformer.AbstractTransformer;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;

@Component
public class PayloadToQueryString extends AbstractTransformer {
    private static final Logger LOG= LoggerFactory.getLogger(PayloadToQueryString.class);

    @Override
    protected Object doTransform(final Message<?> message) throws Exception {
        return MessageBuilder
                .withPayload(urlEncodeUTF8(((MultiValueMap) message.getPayload()).toSingleValueMap()))
                .copyHeaders(message.getHeaders())
                .build();
    }

    private static String urlEncodeUTF8(final String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (final UnsupportedEncodingException e) {
            throw new UnsupportedOperationException(e);
        }
    }
    private static String urlEncodeUTF8(final Map<?,?> map) {
        final StringBuilder sb = new StringBuilder();
        for (final Map.Entry<?,?> entry : map.entrySet()) {
            if (sb.length() > 0) {
                sb.append("&");
            }
            sb.append(String.format("%s=%s",
                    urlEncodeUTF8(entry.getKey().toString()),
                    urlEncodeUTF8(entry.getValue().toString())
            ));
        }
        if(sb.length() > 0) sb.insert(0,'?');
        String queryString = sb.toString();
        LOG.info("Transformed query string:{}", queryString);
        return queryString;
    }
}
