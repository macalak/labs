package ite.librarymaster.application.service;

import ite.librarymaster.application.dto.BookDTO;
import ite.librarymaster.application.exception.ItemNotFoundException;

import java.util.List;

public interface LibraryAdminServiceProxy {
	
	List<BookDTO> getAllBooks();
	BookDTO getBookById(Long id) throws ItemNotFoundException;
	String createBook(BookDTO bookDTO);
	void deleteBook(Long id) throws ItemNotFoundException;
}
