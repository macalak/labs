package ite.librarymaster.application.service;

import ite.librarymaster.application.dto.BookDTO;

import java.util.List;
import java.util.Map;

public interface LibrarySearchServiceProxy {
    List<BookDTO> getBooks(Map<String,String> filter);
}
