package ite.librarymaster.application.api;

import ite.librarymaster.application.dto.BookDTO;
import ite.librarymaster.application.exception.ItemNotFoundException;
import ite.librarymaster.application.service.LibraryAdminServiceProxy;

import ite.librarymaster.application.service.LibrarySearchServiceProxy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Library REST Controller.
 * 
 * @author macalak@itexperts.sk
 *
 */
@RestController
@RequestMapping("/library")
public class LibraryController {
	final private static Logger LOG = LoggerFactory.getLogger(LibraryController.class);
    
    @Autowired
    LibraryAdminServiceProxy libraryAdminServiceProxy;

    @Autowired
    LibrarySearchServiceProxy librarySearchServiceProxy;


    @RequestMapping(produces={"application/json"}, value="/books/{id}", method=RequestMethod.GET )
    public BookDTO getBookById(@PathVariable("id") Long id) throws ItemNotFoundException{
    	LOG.info("Getting book identified by id:{} ...", id);
        return libraryAdminServiceProxy.getBookById(id);
    }

    @RequestMapping(consumes={"application/json"}, produces={"application/json"},value="/books", method=RequestMethod.POST )
    public ResponseEntity createBook(@NotNull @RequestBody BookDTO bookDTO) {
        LOG.info("Creating book with details:{}", bookDTO);
        String location = libraryAdminServiceProxy.createBook(bookDTO);
        return ResponseEntity.created(URI.create(location)).build();
    }

    @RequestMapping(produces={"application/json"}, value="/books/{id}", method=RequestMethod.DELETE )
    public ResponseEntity deleteBook(@PathVariable("id") Long id) throws ItemNotFoundException {
        LOG.info("Deleting book with id{}", id);
        libraryAdminServiceProxy.deleteBook(id);
        return ResponseEntity.ok().build();
    }

    @RequestMapping(produces={"application/json"}, value="/books", method=RequestMethod.GET )
    public List<BookDTO> searchBook(@RequestParam(value = "isbn", required = false) String isbn,
                                    @RequestParam(value = "author", required = false) String author,
                                    @RequestParam(value = "title", required = false) String title) throws ItemNotFoundException {
        LOG.info("Searching for books isbn:{}, author:{}, title:{} ...", isbn, author, title);
        return librarySearchServiceProxy.getBooks(getFilter(isbn,author,title));
    }

    private Map<String,String> getFilter(String isbn, String author, String title){
        HashMap<String,String> filter = new HashMap<>();
        if(isbn!=null && !isbn.isEmpty()) filter.put("ISBN",isbn);
        if(author!=null && !author.isEmpty()) filter.put("AUTHOR",author);
        if(title!=null && !title.isEmpty()) filter.put("TITLE", title);
        return filter;
    }
}
