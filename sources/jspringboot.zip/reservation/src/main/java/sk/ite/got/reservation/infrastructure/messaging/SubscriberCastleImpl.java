package sk.ite.got.reservation.infrastructure.messaging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.stereotype.Service;
import sk.ite.got.castle.domain.event.CastleCreatedEvent;
import sk.ite.got.reservation.domain.model.Castle;
import sk.ite.got.reservation.infrastructure.persistence.CastleRepository;

import javax.validation.constraints.NotNull;

@Service
public class SubscriberCastleImpl {
	final Logger LOG = LoggerFactory.getLogger(SubscriberCastleImpl.class);

	@Autowired
	CastleRepository castleRepository;
	
	@StreamListener(SubscriberCastleInterface.CASTLE_SINK)
	public void receiveCastleCreatedEvent(@NotNull CastleCreatedEvent event) {
		LOG.info("Event received " + event);
		Castle castleToAdd = new Castle(event.getId(), event.getName());
		castleRepository.save(castleToAdd);
	}
}
